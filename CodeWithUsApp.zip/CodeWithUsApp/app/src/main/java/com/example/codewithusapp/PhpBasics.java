package com.example.codewithusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PhpBasics extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_php_basics);
    }
}