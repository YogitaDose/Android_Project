package com.example.codewithusapp;
public class QuestionPhp {
    public static String question[] = {
            "Qno1: Variable name in PHP starts with -",
            "Qno2: Which of the following is correct to add a comment in php?",
            "Qno3: Which of the following is used for concatenation in PHP? ",
            "Qno4: Which of the following starts with __ (double underscore) in PHP?",
            "Qno5: Which of the following is the correct way to create a function in PHP? ",
            "Qno6: String values in PHP must be enclosed within -",
            "Qno7: Which of the following is a built-in function in PHP that adds a value to the end of an array?",
            "Qno8: Which PHP function is used to find the position of the last occurrence of a substring inside another string? ",
            "Qno9: Which of the following is the correct way to print \"Hello World\" in PHP?",
            "Qno10: Which PHP function is capable to read specific number of characters from a file?"

    };
    public static String choices[][]={
            {"! (Exclamation)","$ (Dollar)","& (Ampersand)","# (Hash)"},
            {"& …… &","// ……","/* …… */","Both (b) and (c)"},
            {"+ (plus)","* (Asterisk)",". (dot)","append()"},
            {"Inbuilt constants","User-defined constants","Magic constants","Default constants"},
            {"Create myFunction()","New_function myFunction()","function myFunction()","None of the above"},
            {"Double Quotes","Single Quotes","Both (a) and (b)","None of the above"},
            {"array_push()","inend_array()","into_array()","None of the above"},
            {"strops()","strrpos()","strtr()","None of the above"},
            {"\"Hello World\";","write(\"Hello World\");","echo \"Hello World\";","None of the above"},
            {"filegets()","fget()","fgets()","None of the above"}


    };
    public static String correctAnswers[] ={

            "$ (Dollar)","Both (b) and (c)",". (dot)","Magic constants","function myFunction()"
            ,"Both (a) and (b)","array_push()","strrpos()","echo \"Hello World\";","fgets()"
    };
}