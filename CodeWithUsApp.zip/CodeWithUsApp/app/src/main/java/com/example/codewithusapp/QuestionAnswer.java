package com.example.codewithusapp;
public class QuestionAnswer {
    public static String question[] = {
            "Q.1:Who developed the Python language?",
            "Q.2:What do we use to define a block of code in Python language?",
            "Q.3:What is the method inside the class in python language?",
            "Q.4:Why does the name of local variables start with an underscore discouraged?",
            "Q.5:Which of the following option is not a core data type in the python language?",
            "Q.6:Which of the following is not a keyword in Python language?",
            "Q.7:Which of the following keywords is used for function declaration in Python language?",
            "Q.8:In the Python Programming Language, syntax error is detected by __ at ___.",
            "Q.9:Which of the following blocks allows you to handle the errors?",
            "Q.10:Which of the following keywords is not reversed keyword in python?"
    };
    public static String choices[][]={
            {"Zim Den","Guido van Rossum","Niene Stom","Wick van Rossum"},
            {"Key","Brackets","Indentation","None of these"},
            {"Object","Function","Attribute","Argument"},
            {"To identify the variable","It confuses the interpreter","It indicates a private variable of a class","None of these"},
            {"Dictionary","Lists","Class","All of the above"},
            {"val","raise","try","with"},
            {"def","function_name","define","None of these"},
            {"Interpreter / Compile time","Run time / Interpreter","Interpreter / Run time","Compile time / Run time"},
            {"except block","try block","finally block","None of these"},
            {"None","Class","Goto","and"}

    };
    public static String correctAnswers[] ={

            "Guido van Rossum","Indentation","Function","It indicates a private variable of a class","Class"
            ,"val","def","Interpreter / Run time","except block","goto"
    };
}