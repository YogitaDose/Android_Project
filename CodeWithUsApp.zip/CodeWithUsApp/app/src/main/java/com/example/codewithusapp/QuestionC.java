package com.example.codewithusapp;

public class QuestionC {
    public static String question[] = {
            "Q.1:Which of the following is a logical AND operator?",
            "Q.2:What is the built-in library function for comparing the two strings?",
            "Q.3: Which keyword is used to transfer control from a function back to the calling function?",
            "Q.4:Which data type cannot be checked in switch-case statement?",
            "Q.5:The C variables are case insensitive.",
            "Q.6:Single line comment in C language begins with _______",
            "Q.7:Which of the following is true about C Programming?",
            "Q.8:Functions can only be called either by value or reference.",
            "Q.9: Determine the wrong file opening mode from the following.",
            "Q.10:Are the three declarations char **ball, char *ball[], and char ball[][] same?"
    };
    public static String choices[][]={
            {"||","!","&&","None"},
            {"strcmp()","equals()","str_compare()","string_cmp()"},
            {"return","go back","switch","goto"},
            {"enum","character","integer","float"},

            {"True","False","Maybe","None"},
            {":","/","*/","/*"},
            {"Platform Independent","High level language","Machine Independent","Assembly language"},
            {"True","False","Maybe","None"},
            {"w","a","x","r"},
            {"True","False","Maybe","None"}

    };
    public static String correctAnswers[] ={

            "&&","strcmp()","return","float","False","//","Machine Independent","True","x","False"
    };
}
