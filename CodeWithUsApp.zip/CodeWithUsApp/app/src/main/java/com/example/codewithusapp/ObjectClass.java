package com.example.codewithusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ObjectClass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_object_class);
    }
}