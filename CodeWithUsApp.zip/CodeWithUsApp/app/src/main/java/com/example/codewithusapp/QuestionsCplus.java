package com.example.codewithusapp;
public class QuestionsCplus {
    public static String question[] = {
            "Q.1:Which of the following is the correct identifier?",
            "Q.2:The programming language that has the ability to create new data types is called___.",
            "Q.3:C++ is a _ type of language.",
            "Q.4:Which of the following refers to characteristics of an array?",
            "Q.5:Which of the following is not a kind of inheritance?",
            "Q.6:Which one of the following given methods we usually use to append more than one character at a time?",
            "Q.7:In C++, can a function call itself?",
            "Q.8:Among the following given options, which can be considered as a member of a class?",
            "Q.9:Which of the following comment syntax is correct to create a single-line comment?",
            "Q.10:Which of the following is the address operator?"
    };
    public static String choices[][]={
            {"$var_name","VAR_123","varname@","None of the above"},
            {"Overloaded","Encapsulated","Reprehensible","Extensible"},
            {"High-level Language","Low-level language","Middle-level language","None"},
            {"An array is a set of similar data items","An array is a set of distinct data items",
                    "An array can hold different types of datatypes","None of the above"},
            {"Distributed","Multiple","Multi-level","Hierarchal"},
            {"Append","operator+=","both append & operator+=","Data"},
            {"Yes","No","Compilation Error","Runtime Error"},
            {"Class variable","Member variable","Class functions","Both A and B"},
            {"//Comment","/Comment/","Comment//","None of the above"},
            {"@","#","&","%"}

    };
    public static String correctAnswers[] ={

            "VAR_123","Extensible","Middle-level language","An array is a set of similar data items","Distributed",
            "both append & operator+=","Yes","Member variable","//Comment","&"
    };
}