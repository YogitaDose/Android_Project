package com.example.codewithusapp;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
public class Php extends AppCompatActivity {
    ListView l;
    TextView txtView;
    String []listItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_php);
        l=findViewById(R.id.listview);
        Button btn=(Button)findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Php.this,QuizPhp.class);
                startActivity(i);
            }
        });

        listItem=getResources().getStringArray(R.array.PHPtopics);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,listItem);
        l.setAdapter(adapter);
        l.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0){
                    startActivity(new Intent(Php.this,PhpBasics.class));
                }
                else if(i==1){
                    startActivity(new Intent(Php.this,PhpControlS.class));

                }
                else if(i==2){
                    startActivity(new Intent(Php.this,PhpFunctions.class));

                }
                else if(i==3){
                    startActivity(new Intent(Php.this,PhpAS.class));

                }
                else if(i==4){
                    startActivity(new Intent(Php.this,PhpMath.class));

                }
                else if(i==5){
                    startActivity(new Intent(Php.this,PhpForm.class));
                }
                else if(i==6){
                    startActivity(new Intent(Php.this,PhpState.class));
                }
                else if(i==7){
                    startActivity(new Intent(Php.this,PhpFile.class));
                }
                else if(i==8){
                    startActivity(new Intent(Php.this,PhpMySQLi.class));
                }

            }

        });
    }
}