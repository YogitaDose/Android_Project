package com.example.codewithusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

public class CertificateClang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_certificate_clang);
        EditText e1=(EditText)findViewById(R.id.e1);
        Intent i=getIntent();
        String s= i.getStringExtra("name");
        e1.setText(s);
    }
}